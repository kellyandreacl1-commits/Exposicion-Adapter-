﻿using Adapter_exps;

// Programa principal

class Program
{
    static void Main(string[] args)
    {
        Captain captain = new Captain(new FishingBoatAdapter());
        captain.Row();
    }
}