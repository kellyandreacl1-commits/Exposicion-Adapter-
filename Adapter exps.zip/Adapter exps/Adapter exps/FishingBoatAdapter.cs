﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Adapter (adaptador)
namespace Adapter_exps
{
    public class FishingBoatAdapter : IRowingBoat
        {
            public FishingBoat boat;

            public FishingBoatAdapter()
            {
                boat = new FishingBoat();
            }

            public void Row()
            {
                // Traducción: row() → sail()
                boat.Sail();
            }
    }
}
