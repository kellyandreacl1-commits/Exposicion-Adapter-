﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Cliente (Capitán)
namespace Adapter_exps
{
        public class Captain
        {
            public IRowingBoat rowingBoat;

            public Captain(IRowingBoat rowingBoat)
            {
                this.rowingBoat = rowingBoat;
            }

            public void Row()
            {
                rowingBoat.Row();
            }
        }
}
