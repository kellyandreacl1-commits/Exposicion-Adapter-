﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Adaptee (clase existente incompatible)
namespace Adapter_exps
{
        public class FishingBoat
        {
            public void Sail()
            {
                Console.WriteLine("El bote de pesca está navegando");
            }
        }
}
