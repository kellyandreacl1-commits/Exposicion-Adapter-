﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
// Target (lo que el capitán espera)

namespace Adapter_exps
{
    public interface IRowingBoat
    {
        void Row();
    }

}

